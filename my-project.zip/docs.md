Claro, aqui está a documentação técnica completa para o projeto "Dokra", gerada com base nos arquivos fornecidos e formatada em Markdown.

---

# Documentação Técnica: Dokra System

## 1. Visão Geral do Projeto

**Dokra** é um sistema de análise inteligente de documentos, projetado para ambientes profissionais como cartórios, prefeituras e outros departamentos de serviço público. O objetivo principal do sistema é automatizar e otimizar o fluxo de trabalho de processamento de documentos oficiais, desde o upload até a extração de dados, validação e análise.

A aplicação oferece um dashboard para monitoramento em tempo real, gerenciamento de usuários, uma biblioteca de documentos com filtros avançados e uma interface para visualização detalhada de cada documento, incluindo dados extraídos por OCR (Reconhecimento Óptico de Caracteres) e resultados de validação.

### Tecnologias Principais

O projeto é construído sobre uma stack moderna de desenvolvimento web, focada em performance, escalabilidade e experiência de usuário.

*   **Framework**: [Next.js](https://nextjs.org/) (v15+) com React (v19) e o App Router.
*   **Linguagem**: [TypeScript](https://www.typescriptlang.org/).
*   **Estilização**: [Tailwind CSS](https://tailwindcss.com/) para estilização utilitária e responsiva.
*   **Componentes de UI**: [shadcn/ui](https://ui.shadcn.com/), uma coleção de componentes reutilizáveis construídos sobre [Radix UI](https://www.radix-ui.com/) e estilizados com Tailwind.
*   **Gerenciamento de Formulários**: [React Hook Form](https://react-hook-form.com/) para gerenciamento de estado de formulários e [Zod](https://zod.dev/) para validação de schemas.
*   **Gráficos e Visualização de Dados**: [Recharts](https://recharts.org/) para a criação de gráficos interativos no dashboard de analytics.
*   **Upload de Arquivos**: [React-Dropzone](https://react-dropzone.js.org/) para a interface de arrastar e soltar (drag-and-drop) arquivos.
*   **Ícones**: [Lucide React](https://lucide.dev/) para uma biblioteca de ícones leve e consistente.
*   **Linting**: [ESLint](https://eslint.org/) para garantir a qualidade e a consistência do código.

## 2. Estrutura de Arquivos

A estrutura do projeto segue as convenções do Next.js App Router, organizando o código de forma lógica e modular.

```
dokra-system/
├── app/
│   ├── (dashboard)/            # Grupo de rotas para o layout principal do dashboard
│   │   ├── admin/
│   │   │   └── users/          # Página de gerenciamento de usuários
│   │   ├── analytics/          # Página de análise de dados
│   │   ├── documents/
│   │   │   ├── [id]/page.tsx   # Página de detalhes de um documento específico
│   │   │   └── page.tsx        # Página da biblioteca de documentos
│   │   ├── get-started/        # Página de boas-vindas e introdução
│   │   ├── upload/             # Página para upload de documentos
│   │   ├── layout.tsx          # Layout principal do dashboard (com sidebar)
│   │   └── page.tsx            # Página inicial do dashboard
│   ├── login/                  # Página de login
│   ├── globals.css             # Estilos globais e variáveis de tema do Tailwind
│   ├── layout.tsx              # Layout raiz da aplicação
│   ├── manifest.json           # Metadados para PWA (Progressive Web App)
│   └── not-found.tsx           # Página de erro 404 customizada
├── components/
│   ├── app-sidebar.tsx         # Componente da barra de navegação lateral
│   ├── providers.tsx           # Provedores de contexto (Tema, Tooltip)
│   ├── features/
│   │   └── ThemeSwitcher.tsx   # Componente para alternar tema (claro/escuro)
│   └── ui/                     # Componentes base do shadcn/ui (Button, Card, etc.)
├── hooks/
│   ├── use-mobile.tsx          # Hook para detectar dispositivos móveis
│   └── use-toast.ts            # Hook para gerenciar notificações (toasts)
├── lib/
│   └── utils.ts                # Funções utilitárias (ex: cn para classes CSS)
├── public/                     # Arquivos estáticos (imagens, ícones)
├── styles/                     # Arquivos de estilo (contém um globals.css, mas o principal está em app/)
├── .eslintrc.json              # Configuração do ESLint
├── components.json             # Configuração do shadcn/ui
├── next.config.mjs             # Configuração do Next.js
├── package.json                # Dependências e scripts do projeto
└── tailwind.config.ts          # Configuração do Tailwind CSS
└── tsconfig.json               # Configuração do TypeScript
```

### Descrição dos Arquivos e Pastas Chave

*   `app/`: Contém todas as rotas, layouts e páginas da aplicação, seguindo a convenção do App Router.
*   `app/(dashboard)/`: Um [grupo de rotas](https://nextjs.org/docs/app/building-your-application/routing/route-groups) que compartilha o mesmo layout (`app/(dashboard)/layout.tsx`), que inclui a sidebar e o cabeçalho. Não afeta a URL.
*   `app/login/`: Rota pública para a página de autenticação.
*   `components/`: Armazena todos os componentes React reutilizáveis.
    *   `components/ui/`: O coração do sistema de design. Contém componentes "primitivos" e de baixo nível (como `Button`, `Card`, `Table`, `Input`) gerados e customizados via shadcn/ui.
*   `hooks/`: Centraliza hooks customizados que encapsulam lógica reutilizável.
*   `lib/`: Funções auxiliares e utilitários genéricos, como o `cn` para mesclar classes do Tailwind CSS.
*   `tailwind.config.ts`: Define o tema customizado (cores, fontes, espaçamentos) para o Tailwind CSS, incluindo variáveis para temas claro e escuro.

## 3. Principais Componentes/Módulos

A aplicação é dividida em páginas (rotas), componentes de layout e componentes de UI reutilizáveis.

### Páginas (Rotas Principais)

*   `app/login/page.tsx`: **Página de Login**
    *   **Responsabilidade**: Fornece um formulário para que usuários autorizados acessem o sistema.
    *   **Interação**: Após um login bem-sucedido (simulado), redireciona o usuário para o dashboard principal (`/`).

*   `app/(dashboard)/page.tsx`: **Dashboard Principal**
    *   **Responsabilidade**: Apresenta uma visão geral e resumida do estado do sistema. Exibe métricas chave (documentos processados, precisão), uma lista de documentos recentes e atalhos para ações comuns.
    *   **Componentes Usados**: `Card`, `Badge`, `Button`, `Progress`.

*   `app/(dashboard)/upload/page.tsx`: **Página de Upload**
    *   **Responsabilidade**: Permite que os usuários enviem documentos para processamento. Utiliza `react-dropzone` para uma interface de arrastar e soltar.
    *   **Interação**: Exibe o progresso do upload e o status de cada arquivo (uploading, processing, completed, error). Simula o upload e processamento para fins de demonstração.

*   `app/(dashboard)/documents/page.tsx`: **Biblioteca de Documentos**
    *   **Responsabilidade**: Exibe uma lista paginada e filtrável de todos os documentos no sistema. Permite buscar, filtrar (por status, tipo, departamento) e ordenar os documentos.
    *   **Interação**: Oferece dois modos de visualização (tabela e grade). Cada item da lista leva à página de detalhes do documento.

*   `app/(dashboard)/documents/[id]/page.tsx`: **Página de Detalhes do Documento**
    *   **Responsabilidade**: Mostra informações detalhadas sobre um único documento, incluindo metadados, dados extraídos por OCR, resultados da validação e o texto OCR completo.
    *   **Componentes Usados**: `Tabs` para organizar as informações, `Card` para agrupar dados e `Badge` para status.

*   `app/(dashboard)/admin/users/page.tsx`: **Gerenciamento de Usuários**
    *   **Responsabilidade**: Permite que administradores visualizem, adicionem, editem e removam contas de usuário no sistema.
    *   **Componentes Usados**: `Table` para listar usuários, `Dialog` para o formulário de "Adicionar Usuário", `Input` para busca.

*   `app/(dashboard)/analytics/page.tsx`: **Página de Analytics**
    *   **Responsabilidade**: Apresenta dados e métricas de desempenho do sistema através de gráficos interativos.
    *   **Componentes Usados**: `Tabs`, `Card`, e componentes de gráficos da biblioteca `Recharts` (`BarChart`, `PieChart`, `LineChart`).

### Componentes de Layout e Funcionalidades

*   `components/app-sidebar.tsx`: **Barra Lateral (`AppSidebar`)**
    *   **Responsabilidade**: Componente de navegação principal da aplicação. Exibe os links para as diferentes seções do dashboard.
    *   **Props**: Nenhuma. Utiliza o hook `usePathname` do Next.js para destacar o link ativo.
    *   **Interação**: Os links de navegação são construídos com o componente `<Link>` do Next.js. A estrutura da sidebar é baseada nos componentes customizados de `components/ui/sidebar.tsx`.

*   `components/features/ThemeSwitcher.tsx`: **Seletor de Tema**
    *   **Responsabilidade**: Permite ao usuário alternar entre os temas "Claro", "Escuro" e "Sistema".
    *   **Interação**: Utiliza o hook `useTheme` da biblioteca `next-themes` para aplicar a classe `.dark` no elemento `<html>`, que por sua vez ativa as variáveis de cor escuras definidas no CSS.

*   `components/providers.tsx`: **Provedores (`Providers`)**
    *   **Responsabilidade**: Componente de alto nível que envolve a aplicação para fornecer contextos globais.
    *   **Interação**:
        *   `NextThemesProvider`: Habilita a funcionalidade de troca de temas em toda a aplicação.
        *   `TooltipProvider`: Habilita os tooltips (dicas de contexto) em toda a aplicação.

## 4. Instruções de Instalação e Uso

Para rodar este projeto localmente, siga os passos abaixo.

### Pré-requisitos

*   [Node.js](https://nodejs.org/en/) (versão 18.x ou superior)
*   [npm](https://www.npmjs.com/), [yarn](https://yarnpkg.com/) ou [pnpm](https://pnpm.io/) como gerenciador de pacotes.

### Instalação

1.  Clone o repositório para a sua máquina local:
    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd dokra-system
    ```

2.  Instale as dependências do projeto usando o seu gerenciador de pacotes preferido:
    ```bash
    # Usando npm
    npm install
    
    # Ou usando yarn
    yarn install
    
    # Ou usando pnpm
    pnpm install
    ```

### Como Rodar

Os scripts para executar, testar e construir a aplicação estão definidos no arquivo `package.json`.

1.  **Iniciar o Servidor de Desenvolvimento:**
    Para iniciar a aplicação em modo de desenvolvimento com hot-reloading:
    ```bash
    npm run dev
    ```
    Abra [http://localhost:3000](http://localhost:3000) no seu navegador para ver o resultado.

2.  **Construir para Produção:**
    Para compilar e otimizar a aplicação para produção:
    ```bash
    npm run build
    ```
    Isso criará uma pasta `.next` com os arquivos otimizados.

3.  **Iniciar o Servidor de Produção:**
    Para rodar a versão de produção que foi previamente construída:
    ```bash
    npm run start
    ```
    Isso iniciará um servidor otimizado na porta 3000.

4.  **Executar o Linter:**
    Para verificar o código em busca de erros de estilo e potenciais problemas:
    ```bash
    npm run lint
    ```