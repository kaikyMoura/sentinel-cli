import os
import zipfile
import tempfile
import typer
import shutil
from dotenv import load_dotenv
from google import genai
from fpdf import FPDF

load_dotenv()

ALLOWED_EXTENSIONS = [
    ".js",
    ".ts",
    ".tsx",
    ".json",
    ".css",
    ".html",
    ".md",
    ".py",
    ".go",
    ".rs",
]
MAX_CHAR_LIMIT = 2_000_000

app = typer.Typer(
    help="CLI tool to generate documentation or improvements from a zipped codebase."
)

try:
    client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
except TypeError:
    print("❌ Gemini API key missing. Please check your .env file.")
    raise typer.Exit(code=1)


def read_project_files(project_path: str) -> str:
    """
    Reads all the files in a given project path and returns the content of them concatenated.

    It only reads files with the extensions in ALLOWED_EXTENSIONS and ignores files in directories
    that contain the strings in the list ["node_modules", ".git", ".next", "__pycache__"]

    If the total content exceeds the MAX_CHAR_LIMIT, it prints a warning and returns the content up to that point.

    Returns:
        str: The content of all the files concatenated
    """
    full_content = ""
    print(f"📂 Reading files from: {project_path}")

    for root, _, files in os.walk(project_path):
        if any(
            ignored in root
            for ignored in ["node_modules", ".git", ".next", "__pycache__"]
        ):
            continue

        for file in files:
            if any(file.endswith(ext) for ext in ALLOWED_EXTENSIONS):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        relative_path = os.path.relpath(file_path, project_path)
                        full_content += f"\n\n--- Start of file: {relative_path} ---\n"
                        full_content += content
                        full_content += f"\n--- End of file: {relative_path} ---\n"

                        if len(full_content) > MAX_CHAR_LIMIT:
                            print(
                                "⚠️ Large project detected. Analysis might be partial."
                            )
                            return full_content
                except Exception:
                    pass

    return full_content


def generate_ai_analysis(code_context: str, task: str) -> str:
    """
    Send the code context to the Gemini AI model with a task prompt and
    return the generated Markdown content.

    Args:
        code_context (str): The full content of the codebase.
        task (str): The task to perform, either "documentation" or "improvements".

    Returns:
        str: The generated content.
    """

    print("🤖 Sending context to Gemini 1.5 Pro...")

    task_prompt = ""
    if task == "documentation":
        task_prompt = """
Act as a senior software engineer and generate a professional, clear and concise technical documentation in Markdown.
Include:
1. Project Overview
2. File Structure
3. Key Components & Responsibilities
4. Setup & Usage Instructions
"""
    elif task == "improvements":
        task_prompt = """
Act as a senior software engineer and review the code.
Provide detailed improvement suggestions in Markdown format, categorized by:
1. Code Quality
2. Bug Risks
3. Performance Enhancements
4. Security Best Practices
"""
    else:
        return "❌ Unknown task."

    prompt = f"{task_prompt}\n\nProject Code:\n{code_context}"

    try:
        response = client.models.generate_content(
            model="gemini-2.5-pro", contents=prompt
        )
        return response.text or "⚠️ Gemini API did not return any content."
    except Exception as e:
        return f"❌ Gemini API error: {e}"


def save_as_pdf(text: str, output_path: str):
    """
    Save the given text as a PDF file.

    Args:
        text (str): The text content to be saved in the PDF.
        output_path (str): The file path where the PDF will be saved.

    The function creates a PDF with automatic page breaks and uses Arial font with size 12.
    Each line of the text is added to the PDF as a separate cell.
    """

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    for line in text.split("\n"):
        pdf.multi_cell(0, 10, line)

    pdf.output(output_path)


@app.command()
def analyze(
    zip_file: str = typer.Argument(..., help="Path to the .zip file of the project."),
    task: str = typer.Option(
        "documentation",
        "--task",
        "-t",
        help="Type of analysis: documentation | improvements.",
    ),
    output: str = typer.Option(
        "output.md", "--output", "-o", help="Output Markdown file."
    ),
    pdf: bool = typer.Option(False, "--pdf", help="Also generate a PDF output."),
):
    """
    Analyze a zipped project file to generate documentation or improvement suggestions.

    This function unzips a given project archive, reads its contents, and sends the code context
    to an AI model to generate either documentation or improvement suggestions. The results
    are saved to a specified Markdown file, with an optional PDF output.

    Args:
        zip_file (str): Path to the .zip file of the project.
        task (str): The type of analysis to perform. Either "documentation" or "improvements".
        output (str): The path to save the output Markdown file.
        pdf (bool): Whether to also generate a PDF version of the output.

    Raises:
        typer.Exit: If the zip file is not found, is invalid, or no valid source files are found.
    """

    if not os.path.exists(zip_file):
        print(f"❌ File not found: {zip_file}")
        raise typer.Exit(code=1)

    with tempfile.TemporaryDirectory() as temp_dir:
        print(f"📦 Unzipping '{zip_file}'...")
        try:
            with zipfile.ZipFile(zip_file, "r") as zip_ref:
                zip_ref.extractall(temp_dir)
        except zipfile.BadZipFile:
            print("❌ Invalid ZIP file.")
            raise typer.Exit(code=1)

        project_code = read_project_files(temp_dir)

        if not project_code:
            print("❌ No valid source files found.")
            raise typer.Exit(code=1)

        result = generate_ai_analysis(project_code, task)

    with open(output, "w", encoding="utf-8") as f:
        f.write(result)

    print(f"✅ Markdown file saved to: {output}")

    if pdf:
        pdf_output = output.replace(".md", ".pdf")
        save_as_pdf(result, pdf_output)
        print(f"📄 PDF file saved to: {pdf_output}")


if __name__ == "__main__":
    app()
